#!/bin/sh -e
cask exec ecukes "$@" --no-win
